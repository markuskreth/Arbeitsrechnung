
USE `ArbeitrechnungenBak2`;
-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.0.8    Database: Arbeitrechnungen
-- ------------------------------------------------------
-- Server version	5.5.59-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rechnungen`
--

DROP TABLE IF EXISTS `rechnungen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rechnungen` (
  `rechnungen_id` int(11) NOT NULL AUTO_INCREMENT,
  `adresse` varchar(1240) NOT NULL,
  `betrag` float NOT NULL,
  `datum` datetime NOT NULL,
  `geldeingang` date DEFAULT NULL,
  `pdfdatei` varchar(255) NOT NULL,
  `rechnungnr` varchar(255) NOT NULL,
  `texdatei` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  `zahldatum` date NOT NULL,
  `zusammenfassungen` bit(1) NOT NULL,
  `zusatz1` bit(1) NOT NULL,
  `zusatz2` bit(1) NOT NULL,
  `klienten_id` int(11) NOT NULL,
  PRIMARY KEY (`rechnungen_id`),
  KEY `FK_cs6ewo8cj5mjjh5v51bomhelj` (`klienten_id`),
  CONSTRAINT `FK_cs6ewo8cj5mjjh5v51bomhelj` FOREIGN KEY (`klienten_id`) REFERENCES `klienten` (`klienten_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rechnungen`
--

LOCK TABLES `rechnungen` WRITE;
/*!40000 ALTER TABLE `rechnungen` DISABLE KEYS */;
INSERT INTO `rechnungen` VALUES (1,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',150,'2015-09-30 07:46:29',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-09.pdf\'','MTV Groß-Buchholz-2015-09','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-09.tex\'','2015-09-30 08:02:34','2015-10-30','\0','','\0',1),(4,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',217.5,'2015-10-02 20:39:50',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.pdf\'','MTV Groß-Buchholz-2015-10','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.tex\'','2015-10-02 20:39:58','2015-11-02','\0','','\0',1),(5,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',217.5,'2015-10-02 20:29:53',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.pdf\'','MTV Groß-Buchholz-2015-10','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.tex\'','2015-10-02 20:32:13','2015-11-02','\0','','\0',1),(6,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',262.5,'2015-11-02 21:30:06',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.pdf\'','MTV Groß-Buchholz-2015-10','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-10.tex\'','2015-11-02 21:30:24','2015-12-02','\0','','\0',1),(7,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',412.5,'2015-12-02 22:15:47',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-12.pdf\'','MTV Groß-Buchholz-2015-12','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2015-12.tex\'','2015-12-02 22:15:58','2016-01-02','\0','','\0',1),(8,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',270,'2016-01-31 20:09:59',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-02.pdf\'','MTV Groß-Buchholz-2016-02','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-02.tex\'','2016-02-08 20:10:20','2016-03-08','\0','','\0',1),(9,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',390,'2016-03-02 20:14:07',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-03.pdf\'','MTV Groß-Buchholz-2016-03','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-03.tex\'','2016-03-02 20:14:21','2016-04-02','\0','','\0',1),(10,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',360,'2016-04-30 00:00:00',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07.pdf\'','MTV Groß-Buchholz-2016-07','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07.tex\'','2016-07-27 20:25:09','2016-08-27','\0','','\0',1),(11,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',375,'2016-05-31 00:00:00',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07a.pdf\'','MTV Groß-Buchholz-2016-07a','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07a.tex\'','2016-07-27 20:31:32','2016-08-27','\0','','\0',1),(12,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',322.5,'2016-06-27 00:00:00',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07b.pdf\'','MTV Groß-Buchholz-2016-07b','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07b.tex\'','2016-07-27 22:15:03','2016-08-27','\0','','\0',1),(13,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',180,'2016-07-27 22:17:22',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07c.pdf\'','MTV Groß-Buchholz-2016-07c','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-07c.tex\'','2016-07-27 22:17:28','2016-08-27','\0','','\0',1),(14,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',405,'2016-09-11 08:22:15',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-09.pdf\'','MTV Groß-Buchholz-2016-09','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-09.tex\'','2016-09-25 08:22:48','2016-10-25','\0','','\0',1),(15,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',352.5,'2016-10-09 00:00:00',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-10.pdf\'','MTV Groß-Buchholz-2016-10','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-10.tex\'','2016-10-19 19:46:36','2016-11-19','\0','','\0',1),(16,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',277.5,'2016-11-07 21:55:22',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-11.pdf\'','MTV Groß-Buchholz-2016-11','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2016-11.tex\'','2016-11-07 21:55:30','2016-12-07','\0','','\0',1),(17,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',112.5,'2017-02-08 20:48:58',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-02.pdf\'','MTV Groß-Buchholz-2017-02','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-02.tex\'','2017-02-08 20:49:03','2017-03-08','\0','','\0',1),(18,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',300,'2017-02-08 21:00:58',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-02a.pdf\'','MTV Groß-Buchholz-2017-02a','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-02a.tex\'','2017-02-08 21:01:11','2017-03-08','\0','','\0',1),(19,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',330,'2017-03-01 19:48:54',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-03.pdf\'','MTV Groß-Buchholz-2017-03','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-03.tex\'','2017-03-01 19:49:05','2017-04-01','\0','','\0',1),(20,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',607.5,'2017-06-01 00:00:00',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-05.pdf\'','MTV Groß-Buchholz-2017-05','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-05.tex\'','2017-06-20 21:43:03','2017-07-01','\0','','\0',1),(21,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',195,'2017-06-20 21:50:06',NULL,'\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-06.pdf\'','MTV Groß-Buchholz-2017-06','\'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV_Groß-Buchholz_MTV_Groß-Buchholz-2017-06.tex\'','2017-06-20 21:50:12','2017-07-20','\0','','\0',1),(22,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',255,'2018-02-12 21:46:26',NULL,'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV Groß-Buchholz-2018-02.pdf','MTV Groß-Buchholz-2018-02','/home/data/markus/programming/workspace_java_swing/Arbeitsrechnungen/Tex-Vorlagen/buchholz-abrechnung.tex','2018-02-12 21:46:55','2018-03-12','\0','','\0',1),(23,'MTV Groß-Buchholz\n\nArne Borstelmann\nRotekreuzstr. 25\n30627 Hannover',255,'2018-02-12 21:46:26',NULL,'/home/markus/Dokumente/Trampolin/MTV Groß-Buchholz/rechnungen/MTV Groß-Buchholz-2018-02.pdf','MTV Groß-Buchholz-2018-02','/home/data/markus/programming/workspace_java_swing/Arbeitsrechnungen/Tex-Vorlagen/buchholz-abrechnung.tex','2018-02-12 21:48:31','2018-03-12','\0','','\0',1);
/*!40000 ALTER TABLE `rechnungen` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-15 22:27:06
