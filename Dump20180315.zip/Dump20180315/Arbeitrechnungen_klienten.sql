USE `ArbeitrechnungenBak2`;

-- MySQL dump 10.13  Distrib 5.5.59, for debian-linux-gnu (x86_64)
--
-- Host: 192.168.0.8    Database: Arbeitrechnungen
-- ------------------------------------------------------
-- Server version	5.5.59-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `klienten`
--

DROP TABLE IF EXISTS `klienten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `klienten` (
  `klienten_id` int(11) NOT NULL AUTO_INCREMENT,
  `AAdresse1` varchar(50) NOT NULL,
  `AAdresse2` varchar(50) DEFAULT NULL,
  `AEmail` varchar(30) DEFAULT NULL,
  `AOrt` varchar(50) NOT NULL,
  `APLZ` varchar(5) NOT NULL,
  `ATelefon` varchar(30) DEFAULT NULL,
  `Auftraggeber` varchar(50) NOT NULL,
  `Bemerkungen` longtext,
  `KAdresse1` varchar(50) DEFAULT NULL,
  `KAdresse2` varchar(50) DEFAULT NULL,
  `KEmail` varchar(30) DEFAULT NULL,
  `KOrt` varchar(50) DEFAULT NULL,
  `KPLZ` varchar(5) DEFAULT NULL,
  `KTelefon` varchar(30) DEFAULT NULL,
  `Kunde` varchar(50) DEFAULT NULL,
  `rechnungnummer_bezeichnung` varchar(255) DEFAULT NULL,
  `tex_datei` varchar(255) DEFAULT NULL,
  `Zusatz1` bit(1) DEFAULT NULL,
  `Zusatz1_Name` varchar(100) DEFAULT NULL,
  `Zusatz2` bit(1) DEFAULT NULL,
  `Zusatz2_Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`klienten_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `klienten`
--

LOCK TABLES `klienten` WRITE;
/*!40000 ALTER TABLE `klienten` DISABLE KEYS */;
INSERT INTO `klienten` VALUES (1,'Arne Borstelmann','Rotekreuzstr. 25','info@mtv-gb.de','Hannover','30627','0511-571186','MTV Groß-Buchholz',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','/home/data/markus/programming/workspace_java_swing/Arbeitsrechnungen/Tex-Vorlagen/buchholz-abrechnung.tex','','Teilnehmerzahl',NULL,NULL);
/*!40000 ALTER TABLE `klienten` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-03-15 22:27:06
